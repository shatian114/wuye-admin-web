import React from 'react';
import { Router as DefaultRouter, Route, Switch } from 'react-router-dom';
import dynamic from 'umi/dynamic';
import renderRoutes from 'umi/_renderRoutes';
import RendererWrapper0 from '/home/peng/pzhsq-web/src/pages/.umi/LocaleWrapper.jsx'
import _dvaDynamic from 'dva/dynamic'

let Router = require('dva/router').routerRedux.ConnectedRouter;

let routes = [
  {
    "path": "/user",
    "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "layouts__UserLayout" */'../../layouts/UserLayout'),
  LoadingComponent: require('/home/peng/pzhsq-web/src/components/PageLoading/index').default,
}),
    "routes": [
      {
        "path": "/user",
        "redirect": "/user/login",
        "exact": true
      },
      {
        "path": "/user/login",
        "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import(/* webpackChunkName: 'p__User__models__register.js' */'/home/peng/pzhsq-web/src/pages/User/models/register.js').then(m => { return { namespace: 'register',...m.default}})
],
  component: () => import(/* webpackChunkName: "p__User__Login" */'../User/Login'),
  LoadingComponent: require('/home/peng/pzhsq-web/src/components/PageLoading/index').default,
}),
        "exact": true
      },
      {
        "path": "/user/register",
        "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import(/* webpackChunkName: 'p__User__models__register.js' */'/home/peng/pzhsq-web/src/pages/User/models/register.js').then(m => { return { namespace: 'register',...m.default}})
],
  component: () => import(/* webpackChunkName: "p__User__Register" */'../User/Register'),
  LoadingComponent: require('/home/peng/pzhsq-web/src/components/PageLoading/index').default,
}),
        "exact": true
      },
      {
        "path": "/user/register-result",
        "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import(/* webpackChunkName: 'p__User__models__register.js' */'/home/peng/pzhsq-web/src/pages/User/models/register.js').then(m => { return { namespace: 'register',...m.default}})
],
  component: () => import(/* webpackChunkName: "p__User__RegisterResult" */'../User/RegisterResult'),
  LoadingComponent: require('/home/peng/pzhsq-web/src/components/PageLoading/index').default,
}),
        "exact": true
      },
      {
        "component": () => React.createElement(require('/home/peng/pzhsq-web/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
      }
    ]
  },
  {
    "path": "/",
    "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "layouts__BasicLayout" */'../../layouts/BasicLayout'),
  LoadingComponent: require('/home/peng/pzhsq-web/src/components/PageLoading/index').default,
}),
    "Routes": [require('../Authorized').default],
    "authority": [
      "admin",
      "user"
    ],
    "routes": [
      {
        "path": "/",
        "redirect": "/jiBenXinXi/wuYeGongSi",
        "exact": true
      },
      {
        "path": "/jiBenXinXi",
        "name": "基本信息管理",
        "icon": "dashboard",
        "routes": [
          {
            "path": "/jiBenXinXi/wuYeGongSi",
            "name": "物业公司管理",
            "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "layouts__BasicLayout" */'../jiBenXinXi/wuYeGongSi/wuYeGongSi'),
  LoadingComponent: require('/home/peng/pzhsq-web/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/jiBenXinXi/xiaoQu",
            "name": "小区管理",
            "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "layouts__BasicLayout" */'../jiBenXinXi/xiaoQu/xiaoQu'),
  LoadingComponent: require('/home/peng/pzhsq-web/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/jiBenXinXi/yeZhu",
            "name": "业主管理",
            "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "layouts__BasicLayout" */'../jiBenXinXi/yeZhu/yeZhu'),
  LoadingComponent: require('/home/peng/pzhsq-web/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "component": () => React.createElement(require('/home/peng/pzhsq-web/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "path": "/feiYong",
        "name": "费用管理",
        "icon": "money-collect",
        "routes": [
          {
            "path": "/feiYong/wuYeFei",
            "name": "物业费管理",
            "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "layouts__BasicLayout" */'../feiYong/wuYeFei/wuYeFei'),
  LoadingComponent: require('/home/peng/pzhsq-web/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/feiYong/chongZhiLiuShui",
            "name": "充值流水管理",
            "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "layouts__BasicLayout" */'../feiYong/chongZhiLiuShui/chongZhiLiuShui'),
  LoadingComponent: require('/home/peng/pzhsq-web/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/feiYong/kouFeiJiLu",
            "name": "扣费记录管理",
            "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "layouts__BasicLayout" */'../feiYong/kouFeiJiLu/kouFeiJiLu'),
  LoadingComponent: require('/home/peng/pzhsq-web/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/feiYong/feiYongTaiZhang",
            "name": "费用台帐管理",
            "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "layouts__BasicLayout" */'../feiYong/feiYongTaiZhang/feiYongTaiZhang'),
  LoadingComponent: require('/home/peng/pzhsq-web/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/feiYong/piLiangCuiFei",
            "name": "批量催费管理",
            "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "layouts__BasicLayout" */'../feiYong/piLiangCuiFei/piLiangCuiFei'),
  LoadingComponent: require('/home/peng/pzhsq-web/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/feiYong/piLiangKouFei",
            "name": "批量扣费管理",
            "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "layouts__BasicLayout" */'../feiYong/piLiangKouFei/piLiangKouFei'),
  LoadingComponent: require('/home/peng/pzhsq-web/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "component": () => React.createElement(require('/home/peng/pzhsq-web/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "path": "/tongJiFenXi",
        "name": "统计分析",
        "icon": "line-chart",
        "routes": [
          {
            "path": "/tongJiFenXi/chongZhiLv",
            "name": "充值率统计分析",
            "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "layouts__BasicLayout" */'../tongJiFenXi/chongZhiLv/chongZhiLv'),
  LoadingComponent: require('/home/peng/pzhsq-web/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/tongJiFenXi/qianFeiLv",
            "name": "欠费率统计分析",
            "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "layouts__BasicLayout" */'../tongJiFenXi/qianFeiLv/qianFeiLv'),
  LoadingComponent: require('/home/peng/pzhsq-web/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/tongJiFenXi/liuShuiTongZhi",
            "name": "流水统计分析",
            "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "layouts__BasicLayout" */'../tongJiFenXi/liuShuiTongZhi/liuShuiTongZhi'),
  LoadingComponent: require('/home/peng/pzhsq-web/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/tongJiFenXi/zhiFuLeiXing",
            "name": "支付类型统计分析",
            "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "layouts__BasicLayout" */'../tongJiFenXi/zhiFuLeiXing/zhiFuLeiXing'),
  LoadingComponent: require('/home/peng/pzhsq-web/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/tongJiFenXi/shiDuan",
            "name": "时段同比环比",
            "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "layouts__BasicLayout" */'../tongJiFenXi/shiDuan/shiDuan'),
  LoadingComponent: require('/home/peng/pzhsq-web/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "component": () => React.createElement(require('/home/peng/pzhsq-web/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "path": "/sheQuLunTan",
        "name": "社区论坛",
        "icon": "book",
        "routes": [
          {
            "path": "/sheQuLunTan/huoDong",
            "name": "活动管理",
            "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "layouts__BasicLayout" */'../sheQuLunTan/huoDong/huoDong'),
  LoadingComponent: require('/home/peng/pzhsq-web/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/sheQuLunTan/tieZi",
            "name": "帖子管理",
            "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "layouts__BasicLayout" */'../sheQuLunTan/tieZi/tieZi'),
  LoadingComponent: require('/home/peng/pzhsq-web/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/sheQuLunTan/yongHu",
            "name": "用户管理",
            "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "layouts__BasicLayout" */'../sheQuLunTan/yongHu/yongHu'),
  LoadingComponent: require('/home/peng/pzhsq-web/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "component": () => React.createElement(require('/home/peng/pzhsq-web/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "path": "/woDeSheQu",
        "name": "我的社区",
        "icon": "robot",
        "routes": [
          {
            "path": "/woDeSheQu/sheQuGongGao",
            "name": "社区公告",
            "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "layouts__BasicLayout" */'../woDeSheQu/sheQuGongGao/sheQuGongGao'),
  LoadingComponent: require('/home/peng/pzhsq-web/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/woDeSheQu/juWeiHui",
            "name": "居委会",
            "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "layouts__BasicLayout" */'../woDeSheQu/juWeiHui/juWeiHui'),
  LoadingComponent: require('/home/peng/pzhsq-web/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/woDeSheQu/tongXunLu",
            "name": "通讯录",
            "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "layouts__BasicLayout" */'../woDeSheQu/tongXunLu/tongXunLu'),
  LoadingComponent: require('/home/peng/pzhsq-web/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/woDeSheQu/jianShen",
            "name": "健身",
            "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "layouts__BasicLayout" */'../woDeSheQu/jianShen/jianShen'),
  LoadingComponent: require('/home/peng/pzhsq-web/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/woDeSheQu/tiaoSaoShiChang",
            "name": "跳蚤市场",
            "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "layouts__BasicLayout" */'../woDeSheQu/tiaoSaoShiChang/tiaoSaoShiChang'),
  LoadingComponent: require('/home/peng/pzhsq-web/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "component": () => React.createElement(require('/home/peng/pzhsq-web/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "path": "/sheQuFuWu",
        "name": "社区服务",
        "icon": "filter",
        "routes": [
          {
            "path": "/sheQuFuWu/baoJie",
            "name": "保洁管理",
            "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "layouts__BasicLayout" */'../sheQuFuWu/baoJie/baoJie'),
  LoadingComponent: require('/home/peng/pzhsq-web/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/sheQuFuWu/weiXiu",
            "name": "维修管理",
            "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "layouts__BasicLayout" */'../sheQuFuWu/weiXiu/weiXiu'),
  LoadingComponent: require('/home/peng/pzhsq-web/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/sheQuFuWu/zuLi",
            "name": "租赁管理",
            "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "layouts__BasicLayout" */'../sheQuFuWu/zuLi/zuLi'),
  LoadingComponent: require('/home/peng/pzhsq-web/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "component": () => React.createElement(require('/home/peng/pzhsq-web/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "path": "/zengZhiYeWu",
        "name": "增值业务",
        "icon": "gift",
        "routes": [
          {
            "path": "/zengZhiYeWu/zhouBianShangQuan",
            "name": "周边商圈",
            "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "layouts__BasicLayout" */'../zengZhiYeWu/zhouBianShangQuan/zhouBianShangQuan'),
  LoadingComponent: require('/home/peng/pzhsq-web/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/zengZhiYeWu/xuNiFuWu",
            "name": "虚拟服务",
            "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "layouts__BasicLayout" */'../zengZhiYeWu/xuNiFuWu/xuNiFuWu'),
  LoadingComponent: require('/home/peng/pzhsq-web/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/zengZhiYeWu/dianZiShangCheng",
            "name": "电子商城",
            "routes": [
              {
                "path": "/zengZhiYeWu/dianZiShangCheng/shangPinLeiBie",
                "name": "商品类别",
                "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "layouts__BasicLayout" */'../zengZhiYeWu/dianZiShangCheng/shangPinLeiBie/shangPinLeiBie'),
  LoadingComponent: require('/home/peng/pzhsq-web/src/components/PageLoading/index').default,
}),
                "exact": true
              },
              {
                "path": "/zengZhiYeWu/dianZiShangCheng/shangPin",
                "name": "商品",
                "component": _dvaDynamic({
  
  component: () => import(/* webpackChunkName: "layouts__BasicLayout" */'../zengZhiYeWu/dianZiShangCheng/shangPin/shangPin'),
  LoadingComponent: require('/home/peng/pzhsq-web/src/components/PageLoading/index').default,
}),
                "exact": true
              },
              {
                "component": () => React.createElement(require('/home/peng/pzhsq-web/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
              }
            ]
          },
          {
            "component": () => React.createElement(require('/home/peng/pzhsq-web/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "component": () => React.createElement(require('/home/peng/pzhsq-web/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
      }
    ]
  },
  {
    "component": () => React.createElement(require('/home/peng/pzhsq-web/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
  }
];
window.g_routes = routes;
window.g_plugins.applyForEach('patchRoutes', { initialValue: routes });

export default function RouterWrapper() {
  return (
<RendererWrapper0>
          <Router history={window.g_history}>
      { renderRoutes(routes, {}) }
    </Router>
        </RendererWrapper0>
  );
}
