// create history
window.g_history = require('history/createHashHistory').default();
